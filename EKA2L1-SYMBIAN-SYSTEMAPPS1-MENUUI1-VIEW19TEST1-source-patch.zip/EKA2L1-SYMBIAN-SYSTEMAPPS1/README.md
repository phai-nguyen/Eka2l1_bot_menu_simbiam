# EKA2L1 SYMBIAN-SYSTEMAPPS1 FIX1

This patch is applied **on top of the frozen `N-GAGE-COMPAT1-T9AKN1` baseline**.
It does not alter Java/phoneME, AUDIOFINAL1, AUDIOGUARD1, IPCCTX1, SVCMAP1,
CUBEBSEL1, T9PATH1, or AKNFAD1.

## What it adds

* `launcher::get_system_apps()` enumerates visible AppArc registrations that live on
  the ROM/Z drive. It does not change the existing `get_apps()` filtering or the
  persisted `hide_system_apps` preference.
* `bridge::get_system_apps()` exposes those entries to UIKit.
* The existing Unified Library receives a fourth section, **Hệ thống**, with the
  firmware application's real AppArc caption and existing EKA2L1 icon decoder.
* Selecting a system card reuses the existing `bridge::launch_app(uid)` path. No
  second emulator engine, fake Nokia boot sequence, or hard-coded `menu3.exe` path
  is added. A firmware that registers Menu through AppArc therefore launches its
  own Menu executable by UID.
* System cards expose only Run/Cancel on long-press so firmware shell apps are not
  accidentally hidden or treated as installed games.

## Runtime markers

* `SYMBIAN-SYSTEMAPPS1 ENUM1: enumerated ... visible ROM system app(s)`
* `SYMBIAN-SYSTEMAPPS1 UI1: unified system apps=...`
* `SYMBIAN-SYSTEMAPPS1 LAUNCH1: system uid=0x... name=...`

The first device test should use RM-356/Nokia 5800 and confirm that **Menu** appears
in the Hệ thống section and launches the guest S60v5 menu through its AppArc UID.

## FIX1 — ROOTANCHOR1

The first SYSTEMAPPS1 workflow failed before compilation because the BUILDFIX7
`showAppsScreen` injection leaves an indented whitespace-only line after the unified
reload block. The original patcher required a byte-for-byte multiline anchor and
therefore found zero matches.

FIX1 does not change SYSTEMAPPS1 behavior. It makes the RootViewController reload
and icon-stream anchors semantic/whitespace-tolerant while still requiring exactly
one match and still failing closed on an unexpected source layout.


## MENUUI1-VIEW19TEST1 — Menu3 black-screen / UI hang isolation

Runtime evidence from RM-356 / Nokia 5800 V 60.0.003 shows that direct UID launch
already reaches `menu3.exe`, creates a screen device/window group, starts ALF and
AknIconServer, and begins icon precaching.  The strongest deadlock candidate is a
ViewServer request that reaches final opcode **19**: baseline `view.cpp` logs it as
unimplemented and its `default` branch does **not** complete the IPC.

This test patch changes only `src/emu/services/src/ui/view/view.cpp` in addition to
SYSTEMAPPS1-owned UI/bridge files:

* captures the raw View opcode before EKA1/EKA2/EPoC remapping;
* logs `raw`, normalized/mapped opcode, and EPoC version;
* completes **only final opcode 19** with `KErrNone`;
* leaves every other unknown View opcode on the baseline path;
* does not modify FontBitmapServer, AknIconServer, Java, audio, N-Gage stability,
  T9PATH1, or AKNFAD1.

Runtime markers:

* `SYMBIAN-SYSTEMAPPS1 MENUUI1 VIEWIPC: raw=... mapped=... epocver=...`
* `SYMBIAN-SYSTEMAPPS1 MENUUI1 VIEW19: raw=... final=19 complete=KErrNone`

Interpretation: if Menu draws/responds after this build, opcode 19 non-completion
was a blocking condition.  If the screen remains black, the new markers plus the
existing FBS/AknIcon/SVC diagnostics identify the next blocker without broad stubs.
