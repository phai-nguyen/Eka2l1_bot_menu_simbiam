#!/usr/bin/env python3
import sys
import re
from pathlib import Path

if len(sys.argv) != 2:
    raise SystemExit('usage: apply_symbian_systemapps1.py <upstream-root>')

up = Path(sys.argv[1])
launcher_h = up / 'src/emu/ios/include/ios/launcher.h'
launcher_cpp = up / 'src/emu/ios/src/launcher.cpp'
bridge_h = up / 'src/emu/ios/include/ios/emu_bridge.h'
bridge_mm = up / 'src/emu/ios/src/emu_bridge.mm'
root_mm = up / 'src/emu/ios/app/RootViewController.mm'
unified_mm = up / 'src/emu/ios/app/j2me/EKAUnifiedLibraryViewController.mm'
view_cpp = up / 'src/emu/services/src/ui/view/view.cpp'
svc_cpp = up / 'src/emu/kernel/src/svc.cpp'
libmanager_cpp = up / 'src/emu/kernel/src/libmanager.cpp'
for p in (launcher_h, launcher_cpp, bridge_h, bridge_mm, root_mm, unified_mm, view_cpp, svc_cpp, libmanager_cpp):
    if not p.is_file():
        raise SystemExit(f'SYMBIAN-SYSTEMAPPS1: missing source: {p}')


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise SystemExit(f'SYMBIAN-SYSTEMAPPS1 {label}: expected exactly once, found {count}')
    return text.replace(old, new, 1)


def insert_after_cpp_log_call(text: str, literal: str, insertion: str, label: str) -> str:
    # TRACEFIX1: replay V8..V23 may legitimately change whitespace/arguments in
    # the generic SVCMISS logger. Anchor on its stable format-string literal and
    # locate the complete surrounding LOG_* call by balanced parentheses.
    positions = []
    start = 0
    while True:
        pos = text.find(literal, start)
        if pos < 0:
            break
        positions.append(pos)
        start = pos + len(literal)
    if len(positions) != 1:
        raise SystemExit(
            f'SYMBIAN-SYSTEMAPPS1 {label}: expected one SVCMISS literal, found {len(positions)}')

    literal_pos = positions[0]
    candidates = [
        text.rfind('LOG_ERROR(KERNEL', 0, literal_pos),
        text.rfind('LOG_WARN(KERNEL', 0, literal_pos),
        text.rfind('LOG_INFO(KERNEL', 0, literal_pos),
        text.rfind('LOG_DEBUG(KERNEL', 0, literal_pos),
        text.rfind('LOG_TRACE(KERNEL', 0, literal_pos),
    ]
    call_start = max(candidates)
    if call_start < 0:
        raise SystemExit(f'SYMBIAN-SYSTEMAPPS1 {label}: LOG_* call not found before SVCMISS literal')

    open_pos = text.find('(', call_start, literal_pos)
    if open_pos < 0:
        raise SystemExit(f'SYMBIAN-SYSTEMAPPS1 {label}: LOG_* opening parenthesis not found')

    depth = 0
    in_string = False
    in_char = False
    escaped = False
    close_pos = -1
    for idx in range(open_pos, len(text)):
        ch = text[idx]
        if escaped:
            escaped = False
            continue
        if (in_string or in_char) and ch == '\\':
            escaped = True
            continue
        if in_string:
            if ch == '"':
                in_string = False
            continue
        if in_char:
            if ch == "'":
                in_char = False
            continue
        if ch == '"':
            in_string = True
            continue
        if ch == "'":
            in_char = True
            continue
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
            if depth == 0:
                close_pos = idx
                break
            if depth < 0:
                raise SystemExit(f'SYMBIAN-SYSTEMAPPS1 {label}: malformed LOG_* call')

    if close_pos < 0:
        raise SystemExit(f'SYMBIAN-SYSTEMAPPS1 {label}: LOG_* closing parenthesis not found')
    semi = close_pos + 1
    while semi < len(text) and text[semi] in ' \t':
        semi += 1
    if semi >= len(text) or text[semi] != ';':
        raise SystemExit(f'SYMBIAN-SYSTEMAPPS1 {label}: LOG_* semicolon not found')
    insert_at = semi + 1
    return text[:insert_at] + '\n' + insertion + text[insert_at:]

# -------------------------------------------------------------------------
# CORE ENUM1: expose a dedicated ROM/system-app enumeration path without
# changing launcher::get_apps() or the existing hide-system-apps behavior.
# A ROM/system app is any visible AppArc registration whose landing drive is Z:.
# -------------------------------------------------------------------------
h = launcher_h.read_text(encoding='utf-8')
marker = 'SYMBIAN-SYSTEMAPPS1 ENUM1: enumerate visible ROM/AppArc applications.'
if marker not in h:
    old = '        std::vector<std::string> get_apps();\n'
    new = old + (
        '        // SYMBIAN-SYSTEMAPPS1 ENUM1: enumerate visible ROM/AppArc applications.\n'
        '        // This bypasses the front-end hide_system_apps preference without changing it.\n'
        '        std::vector<std::string> get_system_apps();\n'
    )
    h = replace_once(h, old, new, 'launcher.h declaration')
    launcher_h.write_text(h, encoding='utf-8')
elif 'std::vector<std::string> get_system_apps();' not in h:
    raise SystemExit('SYMBIAN-SYSTEMAPPS1 launcher.h marker present but declaration missing')

c = launcher_cpp.read_text(encoding='utf-8')
marker = 'SYMBIAN-SYSTEMAPPS1 ENUM1: enumerated {} visible ROM system app(s)'
if marker not in c:
    anchor = '    app_icon launcher::get_app_icon(std::uint32_t uid) {\n'
    fn = r'''    std::vector<std::string> launcher::get_system_apps() {
        std::vector<std::string> info;
        if (!alserv) {
            return info;
        }

        // SYMBIAN-SYSTEMAPPS1 ENUM1: AppArc is the source of truth.  Keep
        // hidden registrations hidden, but expose every visible ROM/Z-drive
        // application regardless of the normal hide_system_apps preference.
        std::vector<apa_app_registry> &registerations = alserv->get_registerations();
        for (auto &reg : registerations) {
            if (reg.caps.is_hidden || reg.land_drive != drive_z) {
                continue;
            }
            std::string name = common::ucs2_to_utf8(reg.mandatory_info.long_caption.to_std_string(nullptr));
            if (name.empty()) {
                name = common::ucs2_to_utf8(reg.mandatory_info.short_caption.to_std_string(nullptr));
            }
            info.push_back(std::to_string(reg.mandatory_info.uid));
            info.push_back(name);
        }
        LOG_INFO(FRONTEND_CMDLINE,
            "SYMBIAN-SYSTEMAPPS1 ENUM1: enumerated {} visible ROM system app(s)", info.size() / 2);
        return info;
    }

'''
    c = replace_once(c, anchor, fn + anchor, 'launcher.cpp insertion')
    launcher_cpp.write_text(c, encoding='utf-8')
elif 'std::vector<std::string> launcher::get_system_apps()' not in c:
    raise SystemExit('SYMBIAN-SYSTEMAPPS1 launcher.cpp marker present but function missing')

# -------------------------------------------------------------------------
# BRIDGE1: expose the new list to Objective-C++ while keeping the existing
# direct launch_app(uid) path byte-for-byte untouched.
# -------------------------------------------------------------------------
bh = bridge_h.read_text(encoding='utf-8')
marker = 'SYMBIAN-SYSTEMAPPS1 BRIDGE1: visible ROM/system applications.'
if marker not in bh:
    old = '    std::vector<app_entry> get_apps();\n'
    new = old + (
        '    // SYMBIAN-SYSTEMAPPS1 BRIDGE1: visible ROM/system applications.\n'
        '    std::vector<app_entry> get_system_apps();\n'
    )
    bh = replace_once(bh, old, new, 'emu_bridge.h declaration')
    bridge_h.write_text(bh, encoding='utf-8')
elif 'std::vector<app_entry> get_system_apps();' not in bh:
    raise SystemExit('SYMBIAN-SYSTEMAPPS1 emu_bridge.h marker present but declaration missing')

bm = bridge_mm.read_text(encoding='utf-8')
marker = 'SYMBIAN-SYSTEMAPPS1 BRIDGE1: bridge visible ROM system apps'
if marker not in bm:
    anchor = '    icon_image get_app_icon(std::uint32_t uid) {\n'
    fn = r'''    std::vector<app_entry> get_system_apps() {
        std::lock_guard<std::mutex> guard(g_mutex);
        std::vector<app_entry> result;
        if (!g_state || !g_state->launcher_) {
            return result;
        }
        std::vector<std::string> flat = g_state->launcher_->get_system_apps();
        for (std::size_t i = 0; i + 1 < flat.size(); i += 2) {
            app_entry entry;
            entry.uid = static_cast<std::uint32_t>(std::stoul(flat[i]));
            entry.name = flat[i + 1];
            result.push_back(std::move(entry));
        }
        LOG_INFO(FRONTEND_CMDLINE,
            "SYMBIAN-SYSTEMAPPS1 BRIDGE1: bridge visible ROM system apps count={}", result.size());
        return result;
    }

'''
    bm = replace_once(bm, anchor, fn + anchor, 'emu_bridge.mm insertion')
    bridge_mm.write_text(bm, encoding='utf-8')
elif 'std::vector<app_entry> get_system_apps()' not in bm:
    raise SystemExit('SYMBIAN-SYSTEMAPPS1 emu_bridge.mm marker present but function missing')

# -------------------------------------------------------------------------
# UI1: feed a separate system-app class into the existing Unified Library.
# Existing installed/user Symbian, J2ME and N-Gage routing stays unchanged.
# -------------------------------------------------------------------------
r = root_mm.read_text(encoding='utf-8')
marker = 'SYMBIAN-SYSTEMAPPS1 UI1: enumerate AppArc ROM applications for the unified launcher.'
if marker not in r:
    # SYSTEMAPPS1-FIX1 ROOTANCHOR1:
    # BUILDFIX7 leaves an indented whitespace-only line after this injected block.
    # Match the semantic statements rather than a byte-for-byte triple-quoted block.
    root_reload_pattern = (
        r'(?m)^[ \t]*int unifiedDeviceIndex = eka2l1::ios::bridge::has_device\(\)\r?\n'
        r'[ \t]*\? eka2l1::ios::bridge::get_current_device\(\) : -1;\r?\n'
        r'[ \t]*NSString \*unifiedDeviceKey = \[NSString stringWithFormat:@"%d", unifiedDeviceIndex\];\r?\n'
        r'[ \t]*\[self\.unifiedLibrary reloadWithSymbianApps:list iconCache:self\.iconCache deviceKey:unifiedDeviceKey\];\r?\n'
        r'[ \t]*BOOL unifiedHasItems = \[self\.unifiedLibrary hasAnyItems\];\r?\n'
        r'(?:[ \t]*\r?\n)?'
    )
    new = r'''    // SYMBIAN-SYSTEMAPPS1 UI1: enumerate AppArc ROM applications for the unified launcher.
            // Keep the legacy/user app list untouched; the system list is a host-side view only.
            std::vector<eka2l1::ios::bridge::app_entry> systemApps = eka2l1::ios::bridge::get_system_apps();
            NSMutableSet<NSNumber *> *systemUIDs = [NSMutableSet set];
            for (auto &systemApp : systemApps) [systemUIDs addObject:@(systemApp.uid)];

            NSMutableArray<NSDictionary *> *systemList = [NSMutableArray array];
            NSMutableSet<NSNumber *> *unifiedSeen = [NSMutableSet set];
            NSMutableArray<NSDictionary *> *unifiedList = [NSMutableArray array];
            for (NSDictionary *raw in list) {
                NSMutableDictionary *copy = [raw mutableCopy];
                NSNumber *uid = copy[@"uid"];
                if (uid) {
                    [unifiedSeen addObject:uid];
                    if ([systemUIDs containsObject:uid]) copy[@"system"] = @YES;
                }
                [unifiedList addObject:copy];
            }
            for (auto &systemApp : systemApps) {
                NSNumber *uid = @(systemApp.uid);
                if ([unifiedSeen containsObject:uid]) continue;
                NSString *name = systemApp.name.empty()
                    ? [NSString stringWithFormat:@"0x%08X", systemApp.uid]
                    : [NSString stringWithUTF8String:systemApp.name.c_str()];
                NSDictionary *entry = @{ @"uid":uid, @"name":name ?: @"Ứng dụng hệ thống", @"system":@YES };
                [systemList addObject:entry];
                [unifiedList addObject:entry];
                [unifiedSeen addObject:uid];
            }
            [systemList sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
                return [a[@"name"] compare:b[@"name"] options:NSCaseInsensitiveSearch];
            }];

            int unifiedDeviceIndex = eka2l1::ios::bridge::has_device()
                ? eka2l1::ios::bridge::get_current_device() : -1;
            NSString *unifiedDeviceKey = [NSString stringWithFormat:@"%d", unifiedDeviceIndex];
            [self.unifiedLibrary reloadWithSymbianApps:unifiedList iconCache:self.iconCache deviceKey:unifiedDeviceKey];
            BOOL unifiedHasItems = [self.unifiedLibrary hasAnyItems];
            NSLog(@"SYMBIAN-SYSTEMAPPS1 UI1: unified system apps=%lu all native=%lu",
                  (unsigned long)systemApps.size(), (unsigned long)unifiedList.count);
'''
    r, root_reload_count = re.subn(root_reload_pattern, new, r, count=1)
    if root_reload_count != 1:
        raise SystemExit(
            f'SYMBIAN-SYSTEMAPPS1 RootViewController unified reload semantic block: '
            f'expected exactly once, found {root_reload_count}'
        )

    icon_pattern = r'(?m)^(?P<indent>[ \t]*)\[self loadIconsForApps:list\];\r?$'
    def _add_system_icon_stream(m):
        indent = m.group('indent')
        return (f'{indent}[self loadIconsForApps:list];\n'
                f'{indent}[self loadIconsForApps:systemList];  // SYMBIAN-SYSTEMAPPS1 UI1: stream ROM app icons too.')
    r, icon_count = re.subn(icon_pattern, _add_system_icon_stream, r, count=1)
    if icon_count != 1:
        raise SystemExit(
            f'SYMBIAN-SYSTEMAPPS1 RootViewController system icon stream: '
            f'expected exactly once, found {icon_count}'
        )
    root_mm.write_text(r, encoding='utf-8')
else:
    if 'eka2l1::ios::bridge::get_system_apps()' not in r or '[self loadIconsForApps:systemList]' not in r:
        raise SystemExit('SYMBIAN-SYSTEMAPPS1 RootViewController marker present but UI plumbing incomplete')

u = unified_mm.read_text(encoding='utf-8')
marker = 'SYMBIAN-SYSTEMAPPS1 UI1: separate firmware/system application section.'
if marker not in u:
    # Fallback icon for system apps.
    old = '''        NSString *symbol = [kind isEqualToString:@"j2me"] ? @"gamecontroller.fill" :
                           ([kind isEqualToString:@"ngage"] ? @"gamecontroller.fill" : @"app.fill");'''
    new = '''        NSString *symbol = [kind isEqualToString:@"j2me"] ? @"gamecontroller.fill" :
                           ([kind isEqualToString:@"ngage"] ? @"gamecontroller.fill" :
                           ([kind isEqualToString:@"system"] ? @"square.grid.2x2.fill" : @"app.fill"));'''
    u = replace_once(u, old, new, 'Unified system fallback icon')

    old = '''    NSMutableArray *symbian = [NSMutableArray array];
    NSMutableArray *ngage = [NSMutableArray array];
    for (NSDictionary *raw in apps ?: @[]) {
        NSMutableDictionary *item = [raw mutableCopy];
        NSNumber *uid = item[@"uid"];
        BOOL isNGage = uid && [knownNGage containsObject:uid];
        item[@"kind"] = isNGage ? @"ngage" : @"symbian";
        if (isNGage) [ngage addObject:item]; else [symbian addObject:item];
    }
    NSArray *j2me = [self loadJ2MEGames];

    // Requested order: Symbian -> J2ME -> N-Gage.
    _sections = [NSMutableArray arrayWithObjects:
        @{ @"title":@"Symbian", @"kind":@"symbian", @"items":symbian },
        @{ @"title":@"J2ME", @"kind":@"j2me", @"items":j2me },
        @{ @"title":@"N-Gage", @"kind":@"ngage", @"items":ngage }, nil];'''
    new = '''    // SYMBIAN-SYSTEMAPPS1 UI1: separate firmware/system application section.
    NSMutableArray *symbian = [NSMutableArray array];
    NSMutableArray *system = [NSMutableArray array];
    NSMutableArray *ngage = [NSMutableArray array];
    for (NSDictionary *raw in apps ?: @[]) {
        NSMutableDictionary *item = [raw mutableCopy];
        NSNumber *uid = item[@"uid"];
        BOOL isSystem = [item[@"system"] boolValue];
        BOOL isNGage = !isSystem && uid && [knownNGage containsObject:uid];
        item[@"kind"] = isSystem ? @"system" : (isNGage ? @"ngage" : @"symbian");
        if (isSystem) [system addObject:item];
        else if (isNGage) [ngage addObject:item];
        else [symbian addObject:item];
    }
    [system sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        return [a[@"name"] compare:b[@"name"] options:NSCaseInsensitiveSearch];
    }];
    NSArray *j2me = [self loadJ2MEGames];

    // SYSTEMAPPS1 order: installed Symbian -> firmware/system -> J2ME -> N-Gage.
    _sections = [NSMutableArray arrayWithObjects:
        @{ @"title":@"Symbian", @"kind":@"symbian", @"items":symbian },
        @{ @"title":@"Hệ thống", @"kind":@"system", @"items":system },
        @{ @"title":@"J2ME", @"kind":@"j2me", @"items":j2me },
        @{ @"title":@"N-Gage", @"kind":@"ngage", @"items":ngage }, nil];'''
    u = replace_once(u, old, new, 'Unified section classification')

    old = '''    header.countLabel.text = [NSString stringWithFormat:@"%lu %@", (unsigned long)count,
                              [s[@"kind"] isEqualToString:@"symbian"] ? @"ứng dụng" : @"trò chơi"];'''
    new = '''    BOOL appSection = [s[@"kind"] isEqualToString:@"symbian"] || [s[@"kind"] isEqualToString:@"system"];
    header.countLabel.text = [NSString stringWithFormat:@"%lu %@", (unsigned long)count,
                              appSection ? @"ứng dụng" : @"trò chơi"];'''
    u = replace_once(u, old, new, 'Unified system count label')

    old = '''    if (self.onLaunchSymbian && item[@"uid"]) self.onLaunchSymbian((uint32_t)[item[@"uid"] unsignedLongValue]);'''
    new = '''    if ([kind isEqualToString:@"system"] && item[@"uid"]) {
        NSLog(@"SYMBIAN-SYSTEMAPPS1 LAUNCH1: system uid=0x%08X name=%@",
              (uint32_t)[item[@"uid"] unsignedLongValue], item[@"name"] ?: @"-");
    }
    if (self.onLaunchSymbian && item[@"uid"]) self.onLaunchSymbian((uint32_t)[item[@"uid"] unsignedLongValue]);'''
    u = replace_once(u, old, new, 'Unified system launch marker')

    old = '''    } else {
        uint32_t uid = (uint32_t)[item[@"uid"] unsignedLongValue];
        if (self.onOpenSymbianSettings) {
            [sheet addAction:[UIAlertAction actionWithTitle:@"Cài đặt trò chơi" style:UIAlertActionStyleDefault
                handler:^(UIAlertAction *a){ self.onOpenSymbianSettings(uid, name); }]];
        }
        if (self.onHideSymbian) {
            [sheet addAction:[UIAlertAction actionWithTitle:@"Ẩn ứng dụng" style:UIAlertActionStyleDestructive
                handler:^(UIAlertAction *a){ self.onHideSymbian(uid, name); }]];
        }
    }'''
    new = '''    } else if (![kind isEqualToString:@"system"]) {
        // System/firmware apps intentionally expose only Run + Cancel.  Per-game
        // settings/hide state belong to installed titles, not the ROM shell itself.
        uint32_t uid = (uint32_t)[item[@"uid"] unsignedLongValue];
        if (self.onOpenSymbianSettings) {
            [sheet addAction:[UIAlertAction actionWithTitle:@"Cài đặt trò chơi" style:UIAlertActionStyleDefault
                handler:^(UIAlertAction *a){ self.onOpenSymbianSettings(uid, name); }]];
        }
        if (self.onHideSymbian) {
            [sheet addAction:[UIAlertAction actionWithTitle:@"Ẩn ứng dụng" style:UIAlertActionStyleDestructive
                handler:^(UIAlertAction *a){ self.onHideSymbian(uid, name); }]];
        }
    }'''
    u = replace_once(u, old, new, 'Unified system long-press actions')

    unified_mm.write_text(u, encoding='utf-8')
else:
    required = [
        '@{ @"title":@"Hệ thống", @"kind":@"system"',
        'SYMBIAN-SYSTEMAPPS1 LAUNCH1: system uid=0x%08X name=%@',
        '[kind isEqualToString:@"system"]',
    ]
    for token in required:
        if token not in u:
            raise SystemExit('SYMBIAN-SYSTEMAPPS1 Unified marker present but missing: ' + token)


# -------------------------------------------------------------------------
# MENUUI1-VIEW19TEST1: RM-356 Menu3 reaches the guest ViewServer and then
# emits a final View session opcode 19.  The baseline default branch logs an
# error but never completes the synchronous IPC, which can leave Menu's UI
# thread blocked while unrelated service threads continue.  Keep this test
# deliberately narrow: log raw->mapped opcode/version and complete only final
# opcode 19 with KErrNone.  Do not alter the generic unknown-opcode fallback.
# -------------------------------------------------------------------------
v = view_cpp.read_text(encoding='utf-8')
view_marker = 'SYMBIAN-SYSTEMAPPS1 MENUUI1 VIEWIPC: raw={} mapped={} epocver={}'
if view_marker not in v:
    old = '''    void view_session::fetch(service::ipc_context *ctx) {
        kernel_system *kern = server<view_server>()->get_kernel_object_owner();
'''
    new = old + '''        const auto systemapps1_raw_view_opcode = ctx->msg->function;
'''
    v = replace_once(v, old, new, 'MENUUI1 view raw-opcode capture')

    switch_anchor = '''        switch (ctx->msg->function) {
'''
    switch_prefix = '''        LOG_INFO(SERVICE_UI,
            "SYMBIAN-SYSTEMAPPS1 MENUUI1 VIEWIPC: raw={} mapped={} epocver={}",
            systemapps1_raw_view_opcode, ctx->msg->function,
            static_cast<int>(kern->get_epoc_version()));

'''
    v = replace_once(v, switch_anchor, switch_prefix + switch_anchor,
                     'MENUUI1 view mapping diagnostic')

    bg_anchor = '''        case view_opcode_set_background_color: {
'''
    view19_handler = '''        case view_opcode_set_cross_check_uid: {
            // MENUUI1-VIEW19TEST1: observed as the final normalized opcode on
            // RM-356/Menu3.  Completing this one request isolates the suspected
            // ViewServer deadlock without masking other unknown View opcodes.
            LOG_WARN(SERVICE_UI,
                "SYMBIAN-SYSTEMAPPS1 MENUUI1 VIEW19: raw={} final=19 complete=KErrNone",
                systemapps1_raw_view_opcode);
            ctx->complete(epoc::error_none);
            break;
        }

'''
    v = replace_once(v, bg_anchor, view19_handler + bg_anchor,
                     'MENUUI1 final opcode 19 completion')
    view_cpp.write_text(v, encoding='utf-8')
else:
    required = [
        'const auto systemapps1_raw_view_opcode = ctx->msg->function;',
        'case view_opcode_set_cross_check_uid:',
        'SYMBIAN-SYSTEMAPPS1 MENUUI1 VIEW19: raw={} final=19 complete=KErrNone',
    ]
    for token in required:
        if token not in v:
            raise SystemExit('MENUUI1 view marker present but missing: ' + token)

# -------------------------------------------------------------------------
# MENUUI2-XNTHEME-CRASH-TRACE1: diagnostic-only trace after VIEW19 success.
# Device evidence shows Menu rendezvous succeeds, xnthemeserver starts, then the
# host log stops immediately after a second KErrNotSupported leave. The V11
# 'last IPC' snapshot points at !FileServer opcode 0x27, but 0x27 is FileFlush,
# so it is correlation rather than proof of causality. Trace the IPC dispatch,
# User::Leave trap transition and the two observed missing SVCs without changing
# any guest-visible return value or mapping.
# -------------------------------------------------------------------------
s = svc_cpp.read_text(encoding='utf-8')
trace_marker = 'SYMBIAN-SYSTEMAPPS1 MENUUI2 FS27 PRE:'
if trace_marker not in s:
    old = '''        kern->call_ipc_send_callbacks(server_name, ord, arg, status.ptr_address(), kern->crr_thread());

        const int result = sync ? ss->send_receive_sync(ord, arg, status) : ss->send_receive(ord, arg, status);

        if (ss->get_server()->is_hle()) {
            // Process it right away.
            ss->get_server()->process_accepted_msg();
        }

        return result;
'''
    new = '''        // SYMBIAN-SYSTEMAPPS1 MENUUI2 TRACE BEGIN: FileServer 0x27
        const bool systemapps1_menuui2_fs27 = (server_name == "!FileServer") && (ord == 0x27);
        if (systemapps1_menuui2_fs27) {
            const std::string process_name = kern->crr_process() ? kern->crr_process()->name() : std::string("<none>");
            const std::string thread_name = kern->crr_thread() ? kern->crr_thread()->name() : std::string("<none>");
            auto *cpu = kern->get_cpu();
            LOG_ERROR(KERNEL,
                "SYMBIAN-SYSTEMAPPS1 MENUUI2 FS27 PRE: process='{}' thread='{}' sync={} handle=0x{:X} status=0x{:08X} pc=0x{:08X} lr=0x{:08X} args=[0x{:08X},0x{:08X},0x{:08X},0x{:08X}] flags=0x{:08X}",
                process_name, thread_name, sync ? 1 : 0, h, status.ptr_address(),
                cpu ? cpu->get_pc() : 0, cpu ? cpu->get_lr() : 0,
                arg.args[0], arg.args[1], arg.args[2], arg.args[3], arg.flag);
        }
        // SYMBIAN-SYSTEMAPPS1 MENUUI2 TRACE END: FileServer 0x27 pre

        kern->call_ipc_send_callbacks(server_name, ord, arg, status.ptr_address(), kern->crr_thread());

        const int result = sync ? ss->send_receive_sync(ord, arg, status) : ss->send_receive(ord, arg, status);

        // SYMBIAN-SYSTEMAPPS1 MENUUI2 TRACE BEGIN: FileServer 0x27 post-dispatch
        if (systemapps1_menuui2_fs27) {
            LOG_ERROR(KERNEL,
                "SYMBIAN-SYSTEMAPPS1 MENUUI2 FS27 POST-DISPATCH: result={} hle={}",
                result, ss->get_server()->is_hle() ? 1 : 0);
        }
        // SYMBIAN-SYSTEMAPPS1 MENUUI2 TRACE END: FileServer 0x27 post-dispatch

        if (ss->get_server()->is_hle()) {
            // Process it right away.
            if (systemapps1_menuui2_fs27) {
                LOG_ERROR(KERNEL, "SYMBIAN-SYSTEMAPPS1 MENUUI2 FS27 PRE-PROCESS: entering HLE service dispatch");
            }
            ss->get_server()->process_accepted_msg();
            if (systemapps1_menuui2_fs27) {
                LOG_ERROR(KERNEL, "SYMBIAN-SYSTEMAPPS1 MENUUI2 FS27 POST-PROCESS: HLE service dispatch returned");
            }
        }

        return result;
'''
    s = replace_once(s, old, new, 'MENUUI2 FileServer 0x27 dispatch trace')

    old = '''        thr->increase_leave_depth();

        return current_local_data(kern)->trap_handler;
    }

    BRIDGE_FUNC(void, leave_end) {
        kernel::thread *thr = kern->crr_thread();
        thr->decrease_leave_depth();

        if (thr->is_invalid_leave()) {
            LOG_CRITICAL(KERNEL, "Invalid leave, leave depth is negative!");
        }

        LOG_TRACE(KERNEL, "Leave trapped by trap handler.");
    }
'''
    new = '''        // SYMBIAN-SYSTEMAPPS1 MENUUI2 TRACE BEGIN: leave/trap transition
        const std::string systemapps1_menuui2_leave_process = kern->crr_process()
            ? kern->crr_process()->name() : std::string("<none>");
        const std::string systemapps1_menuui2_leave_thread = thr ? thr->name() : std::string("<none>");
        const bool systemapps1_menuui2_xntheme =
            systemapps1_menuui2_leave_process.find("xnthemeserver") != std::string::npos;
        if (systemapps1_menuui2_xntheme) {
            auto *cpu = kern->get_cpu();
            LOG_ERROR(KERNEL,
                "SYMBIAN-SYSTEMAPPS1 MENUUI2 LEAVE ENTER: code={} process='{}' thread='{}' pc=0x{:08X} lr=0x{:08X} trap=0x{:08X}",
                leave_code, systemapps1_menuui2_leave_process, systemapps1_menuui2_leave_thread,
                cpu ? cpu->get_pc() : 0, cpu ? cpu->get_lr() : 0,
                current_local_data(kern)->trap_handler.ptr_address());
        }
        // SYMBIAN-SYSTEMAPPS1 MENUUI2 TRACE END: leave/trap transition pre-depth

        thr->increase_leave_depth();

        // SYMBIAN-SYSTEMAPPS1 MENUUI2 TRACE BEGIN: leave_start return
        if (systemapps1_menuui2_xntheme) {
            LOG_ERROR(KERNEL,
                "SYMBIAN-SYSTEMAPPS1 MENUUI2 LEAVE RETURN: process='{}' thread='{}' trap=0x{:08X}",
                systemapps1_menuui2_leave_process, systemapps1_menuui2_leave_thread,
                current_local_data(kern)->trap_handler.ptr_address());
        }
        // SYMBIAN-SYSTEMAPPS1 MENUUI2 TRACE END: leave_start return

        return current_local_data(kern)->trap_handler;
    }

    BRIDGE_FUNC(void, leave_end) {
        kernel::thread *thr = kern->crr_thread();
        const std::string systemapps1_menuui2_end_process = kern->crr_process()
            ? kern->crr_process()->name() : std::string("<none>");
        const std::string systemapps1_menuui2_end_thread = thr ? thr->name() : std::string("<none>");
        const bool systemapps1_menuui2_end_xntheme =
            systemapps1_menuui2_end_process.find("xnthemeserver") != std::string::npos;
        if (systemapps1_menuui2_end_xntheme) {
            auto *cpu = kern->get_cpu();
            LOG_ERROR(KERNEL,
                "SYMBIAN-SYSTEMAPPS1 MENUUI2 LEAVE_END ENTER: process='{}' thread='{}' pc=0x{:08X} lr=0x{:08X}",
                systemapps1_menuui2_end_process, systemapps1_menuui2_end_thread,
                cpu ? cpu->get_pc() : 0, cpu ? cpu->get_lr() : 0);
        }

        thr->decrease_leave_depth();

        if (thr->is_invalid_leave()) {
            LOG_CRITICAL(KERNEL, "Invalid leave, leave depth is negative!");
        }

        LOG_TRACE(KERNEL, "Leave trapped by trap handler.");
        if (systemapps1_menuui2_end_xntheme) {
            auto *cpu = kern->get_cpu();
            LOG_ERROR(KERNEL,
                "SYMBIAN-SYSTEMAPPS1 MENUUI2 LEAVE_END EXIT: process='{}' thread='{}' pc=0x{:08X} lr=0x{:08X}",
                systemapps1_menuui2_end_process, systemapps1_menuui2_end_thread,
                cpu ? cpu->get_pc() : 0, cpu ? cpu->get_lr() : 0);
        }
    }
'''
    s = replace_once(s, old, new, 'MENUUI2 leave/trap trace')
    svc_cpp.write_text(s, encoding='utf-8')
else:
    required = [
        'SYMBIAN-SYSTEMAPPS1 MENUUI2 FS27 POST-PROCESS: HLE service dispatch returned',
        'SYMBIAN-SYSTEMAPPS1 MENUUI2 LEAVE ENTER:',
        'SYMBIAN-SYSTEMAPPS1 MENUUI2 LEAVE RETURN:',
        'SYMBIAN-SYSTEMAPPS1 MENUUI2 LEAVE_END ENTER:',
        'SYMBIAN-SYSTEMAPPS1 MENUUI2 LEAVE_END EXIT:',
    ]
    for token in required:
        if token not in s:
            raise SystemExit('MENUUI2 svc marker present but missing: ' + token)

lm = libmanager_cpp.read_text(encoding='utf-8')
svc_marker = 'SYMBIAN-SYSTEMAPPS1 MENUUI2 SVCMISS:'
if svc_marker not in lm:
    trace = '''                // SYMBIAN-SYSTEMAPPS1 MENUUI2 TRACE BEGIN: observed missing SVCs
                if ((svcnum == 0xAB) || (svcnum == 0x00800018)) {
                    const std::string process_name = kern_->crr_process()
                        ? kern_->crr_process()->name() : std::string("<none>");
                    const std::string thread_name = kern_->crr_thread()
                        ? kern_->crr_thread()->name() : std::string("<none>");
                    const char *mapping_hint = (svcnum == 0xAB)
                        ? "v93=message_kill; current epoc95=v10-base slot unmapped"
                        : "current epoc95=v10-base fast-exec slot unmapped";
                    LOG_ERROR(KERNEL,
                        "SYMBIAN-SYSTEMAPPS1 MENUUI2 SVCMISS: svc=0x{:X} epocver={} process='{}' thread='{}' pc=0x{:08X} lr=0x{:08X} r0=0x{:08X} r1=0x{:08X} r2=0x{:08X} r3=0x{:08X} hint='{}'",
                        svcnum, static_cast<int>(kern_->get_epoc_version()), process_name, thread_name,
                        cpu->get_pc(), cpu->get_lr(), cpu->get_reg(0), cpu->get_reg(1),
                        cpu->get_reg(2), cpu->get_reg(3), mapping_hint);
                }
                // SYMBIAN-SYSTEMAPPS1 MENUUI2 TRACE END: observed missing SVCs
'''
    lm = insert_after_cpp_log_call(
        lm,
        'V5 SVCMISS: svc=0x{:X} pc=0x{:08X}',
        trace,
        'MENUUI2 TRACEFIX1 libmanager generic SVCMISS')
    libmanager_cpp.write_text(lm, encoding='utf-8')
else:
    for token in ['svcnum == 0xAB', 'svcnum == 0x00800018', 'v93=message_kill']:
        if token not in lm:
            raise SystemExit('MENUUI2 libmanager marker present but missing: ' + token)

# Final source invariants.  Direct UID launch is intentionally the pre-existing path.
checks = {
    launcher_h: ['std::vector<std::string> get_system_apps();'],
    launcher_cpp: ['std::vector<std::string> launcher::get_system_apps()', 'reg.land_drive != drive_z'],
    bridge_h: ['std::vector<app_entry> get_system_apps();'],
    bridge_mm: ['std::vector<app_entry> get_system_apps()', 'g_state->launcher_->get_system_apps()'],
    root_mm: ['eka2l1::ios::bridge::get_system_apps()', 'SYMBIAN-SYSTEMAPPS1 UI1: unified system apps='],
    unified_mm: ['@"Hệ thống"', 'SYMBIAN-SYSTEMAPPS1 LAUNCH1: system uid=0x%08X name=%@'],
    view_cpp: ['SYMBIAN-SYSTEMAPPS1 MENUUI1 VIEWIPC: raw={} mapped={} epocver={}',
               'SYMBIAN-SYSTEMAPPS1 MENUUI1 VIEW19: raw={} final=19 complete=KErrNone',
               'case view_opcode_set_cross_check_uid:'],
    svc_cpp: ['SYMBIAN-SYSTEMAPPS1 MENUUI2 FS27 PRE:',
              'SYMBIAN-SYSTEMAPPS1 MENUUI2 FS27 POST-PROCESS: HLE service dispatch returned',
              'SYMBIAN-SYSTEMAPPS1 MENUUI2 LEAVE RETURN:',
              'SYMBIAN-SYSTEMAPPS1 MENUUI2 LEAVE_END EXIT:'],
    libmanager_cpp: ['SYMBIAN-SYSTEMAPPS1 MENUUI2 SVCMISS:', 'svcnum == 0xAB', 'svcnum == 0x00800018'],
}
for p, tokens in checks.items():
    txt = p.read_text(encoding='utf-8')
    for token in tokens:
        if token not in txt:
            raise SystemExit(f'SYMBIAN-SYSTEMAPPS1 final gate missing {token!r} in {p}')

# Do not replace or fork the existing UID launch path.
if 'void launch_app(std::uint32_t uid);' not in bridge_h.read_text(encoding='utf-8'):
    raise SystemExit('SYMBIAN-SYSTEMAPPS1 direct UID launch regression: bridge launch_app declaration missing')
if 'eka2l1::ios::bridge::launch_app(uid);' not in root_mm.read_text(encoding='utf-8'):
    raise SystemExit('SYMBIAN-SYSTEMAPPS1 direct UID launch regression: RootViewController launch path missing')

print('SYMBIAN-SYSTEMAPPS1: ENUM1 + BRIDGE1 + UI1 + MENUUI1-VIEW19TEST1 + MENUUI2-XNTHEME-CRASH-TRACE1 applied/verified')
