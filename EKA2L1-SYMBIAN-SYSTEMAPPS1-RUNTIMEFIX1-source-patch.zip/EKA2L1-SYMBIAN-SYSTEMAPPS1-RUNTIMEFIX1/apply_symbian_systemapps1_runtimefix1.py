#!/usr/bin/env python3
import re
import sys
from pathlib import Path

MARKER = "SYMBIAN-SYSTEMAPPS1 RUNTIMEFIX1 BACKUP1: enabling HLE !BackupServer for epoc95"


def fail(msg: str) -> None:
    raise SystemExit("RUNTIMEFIX1: " + msg)


def main() -> None:
    if len(sys.argv) != 2:
        fail("usage: apply_symbian_systemapps1_runtimefix1.py <upstream-root>")

    root = Path(sys.argv[1]).resolve()
    init_cpp = root / "src/emu/services/src/init.cpp"
    backup_cpp = root / "src/emu/services/src/backup/backup.cpp"

    for p in (init_cpp, backup_cpp):
        if not p.is_file():
            fail(f"required source missing: {p}")

    init_text = init_cpp.read_text(encoding="utf-8")
    backup_text = backup_cpp.read_text(encoding="utf-8")

    # Baseline gates. RUNTIMEFIX1 is intentionally based on the accepted
    # SYSTEMAPPS1/FIX2 chain and must not silently apply to another tree.
    if 'V7 AKNICON95: enabling HLE !AknIconServer for epoc95' not in init_text:
        fail("V7 AKNICON95 epoc95 baseline marker missing from init.cpp")
    if MARKER in init_text or "RUNTIMEFIX1 BACKUP1" in backup_text:
        fail("patch appears to be already applied")

    legacy_line = "CREATE_SERVER(sys, backup_old_server);"
    if init_text.count(legacy_line) != 1:
        fail(f"expected exactly one legacy backup_old_server registration, found {init_text.count(legacy_line)}")

    legacy_if = "            if (sys->get_symbian_version_use() <= epocver::eka2) {"
    if init_text.count(legacy_if) != 1:
        fail(f"expected exactly one <= eka2 service branch anchor, found {init_text.count(legacy_if)}")

    # backup_old_server is already implemented by upstream, but its historical
    # service name is "BackupServer". S60v5 Menu3 asks for "!BackupServer".
    # Keep legacy EKA1/EKA2 naming byte-for-byte in behavior and use the bang
    # name only when the same HLE implementation is instantiated for epoc95.
    ctor_re = re.compile(
        r'(?P<prefix>(?:service::)?typical_server\s*\(\s*sys\s*,\s*)'
        r'"BackupServer"(?P<suffix>\s*\))'
    )
    ctor_matches = list(ctor_re.finditer(backup_text))
    if len(ctor_matches) != 1:
        fail(f"expected exactly one BackupServer constructor initializer, found {len(ctor_matches)}")

    replacement = (
        r'\g<prefix>(sys->get_symbian_version_use() == epocver::epoc95) '
        r'? "!BackupServer" : "BackupServer"\g<suffix> '
        r'/* SYMBIAN-SYSTEMAPPS1 RUNTIMEFIX1 BACKUP1 */'
    )
    backup_text = ctor_re.sub(replacement, backup_text, count=1)

    # Ensure eka2l1::system and epocver are complete/visible for the conditional
    # constructor initializer. Do not duplicate an include already present.
    system_include = "#include <system/epoc.h>"
    if system_include not in backup_text:
        include_re = re.compile(r'(?m)^#include\s*[<"]services/backup/backup\.h[>"]\s*$')
        includes = list(include_re.finditer(backup_text))
        if len(includes) != 1:
            fail("could not find a unique backup.h include anchor in backup.cpp")
        m = includes[0]
        backup_text = backup_text[:m.end()] + "\n" + system_include + backup_text[m.end():]

    runtime_block = f'''            // SYMBIAN-SYSTEMAPPS1 RUNTIMEFIX1 BACKUP1:
            // RM-356/S60v5 Menu3 can stall while the native baksrvs process is
            // starting, before it registers !BackupServer. EKA2L1 already has
            // an HLE backup_old_server; expose that implementation only on
            // epoc95 under the S60v5 service name so the real IPC opcodes can
            // be observed without changing the EKA1/EKA2 backup path.
            if (sys->get_symbian_version_use() == epocver::epoc95) {{
                LOG_INFO(SERVICE_UI, "{MARKER}");
                CREATE_SERVER(sys, backup_old_server);
            }}

'''
    init_text = init_text.replace(legacy_if, runtime_block + legacy_if, 1)

    # Post-patch structural gates.
    if init_text.count(MARKER) != 1:
        fail("runtime marker count is not exactly one after patch")
    if init_text.count(legacy_line) != 2:
        fail("expected epoc95 + legacy backup_old_server registrations after patch")
    if init_text.find(MARKER) > init_text.find(legacy_if):
        fail("epoc95 HLE registration was not inserted before the legacy branch")
    if 'sys->get_symbian_version_use() == epocver::epoc95' not in backup_text:
        fail("conditional BackupServer/!BackupServer constructor missing after patch")
    if backup_text.count('"!BackupServer"') != 1:
        fail("expected exactly one !BackupServer literal in backup.cpp")
    if backup_text.count('"BackupServer"') < 1:
        fail("legacy BackupServer name was not preserved")

    init_cpp.write_text(init_text, encoding="utf-8")
    backup_cpp.write_text(backup_text, encoding="utf-8")

    print("RUNTIMEFIX1 BACKUP1 applied")
    print(f"  modified: {init_cpp.relative_to(root)}")
    print(f"  modified: {backup_cpp.relative_to(root)}")
    print("  epoc95 service: !BackupServer (existing backup_old_server HLE)")
    print("  <= EKA2 service: BackupServer (unchanged behavior)")


if __name__ == "__main__":
    main()
