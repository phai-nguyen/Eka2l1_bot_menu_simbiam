EKA2L1 SYMBIAN-SYSTEMAPPS1 RUNTIMEFIX1 / BACKUP1
================================================

Purpose
-------
The RM-356 Menu3 runtime test reached native baksrvs.exe while opening the
S60v5 system Menu, but the tested run stopped after baksrvs created its heap
and before the guest registered !BackupServer.

EKA2L1 already contains backup_old_server HLE. Its historical server name is
BackupServer (without '!'), so merely enabling it on epoc95 would not satisfy
Menu3's !BackupServer session request.

RUNTIMEFIX1 does exactly two source changes:
1. src/emu/services/src/init.cpp
   - enables existing backup_old_server only for epoc95/S60v5;
   - emits marker:
     SYMBIAN-SYSTEMAPPS1 RUNTIMEFIX1 BACKUP1: enabling HLE !BackupServer for epoc95
2. src/emu/services/src/backup/backup.cpp
   - names the HLE !BackupServer only on epoc95;
   - keeps the historical BackupServer name on EKA1/EKA2.

This is a diagnostic compatibility build, not a claim that BackupServer is the
last S60v5 blocker. Existing backup_old_session handling/logging is retained,
including its unknown-opcode diagnostic.

Frozen baselines
----------------
- EKA2L1-JAVA-STABLE1-FROZEN
- N-GAGE-STABILITY1-CUBEB1-FROZEN
- N-GAGE-COMPAT1-T9AKN1-FROZEN
- Existing SYMBIAN-SYSTEMAPPS1 enumeration/bridge/UI/UID-launch path

Repository layout
-----------------
Keep the existing baseline payload in the repository root:
  EKA2L1-SYMBIAN-SYSTEMAPPS1-FIX1-PAYLOAD.zip

Add this new file to the repository root:
  EKA2L1-SYMBIAN-SYSTEMAPPS1-RUNTIMEFIX1-source-patch.zip

Add the workflow under .github/workflows/:
  build-ios-symbian-systemapps1-runtimefix1-manual.yml

Runtime test
------------
1. Run the workflow manually.
2. Sign/install EKA2L1-SYMBIAN-SYSTEMAPPS1-RUNTIMEFIX1-unsigned.ipa.
3. Use the same RM-356 firmware/device state from the SYSTEMAPPS1 test.
4. Open Apps/Hệ thống and launch Menu (UID 0x101F4CD2).
5. Record from the tap until the S60 menu stabilizes, an error appears, or the
   black-screen state has clearly stopped progressing.
6. Send the video plus EKA2L1.log, EKA2L1_TakeThis.log and
   EKA2L1_Persistent.log.

Expected diagnostic change
--------------------------
At emulator startup the log should contain the RUNTIMEFIX1 BACKUP1 marker.
After tapping Menu, the old path should no longer need:
  Create session to unexist server: !BackupServer
  Trying to summon: baksrvs

If Menu3 reaches a BackupServer IPC not implemented by the existing HLE, the
log should expose an "Unimplemented opcode for Old Backup server" message.
That opcode (or the next service/error after it) becomes the next blocker.
